from flask import Flask, render_template, request
from models.car_model import predict_car_price
from models.bike_model import predict_bike_price

app = Flask(__name__)

@app.route('/')
def main_page():
    return render_template('main.html')

# Car Price Prediction
@app.route('/car', methods=['GET', 'POST'])
def car_index():
    predicted_price = None
    user_input = {}
    if request.method == 'POST':
        user_input = {
            'brand': request.form['brand'],
            'model': request.form['model'],
            'model_year': int(request.form['model_year']),
            'fuel_type': request.form['fuel_type'],
            'engine': request.form['engine'],
            'transmission': request.form['transmission'],
            'ext_col': request.form['ext_col'],
            'accident': request.form['accident'],
            'clean_title': request.form['clean_title']
        }
        predicted_price = predict_car_price(**user_input)
    return render_template('car_index.html', predicted_price=predicted_price, user_input=user_input)

# Bike Price Prediction
@app.route('/bike', methods=['GET', 'POST'])
def bike_index():
    predicted_price = None
    user_input = {}
    if request.method == 'POST':
        user_input = {
            'bike_name': request.form['bike_name'],
            'kms_driven': int(request.form['kms_driven']),
            'age': int(request.form['age']),
            'power': float(request.form['power']),
            'brand': request.form['brand']
        }
        predicted_price = predict_bike_price(**user_input)
    return render_template('bike_index.html', predicted_price=predicted_price, user_input=user_input)

if __name__ == '__main__':
    app.run(debug=True)
